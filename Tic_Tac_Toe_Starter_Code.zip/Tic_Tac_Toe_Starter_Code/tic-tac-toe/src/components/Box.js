import React from 'react';

import "./Box.css"
    // Taking the value of the box and checking if it is an X or an O
const Box = ({value, onClick}) => {
// Created a style variable and assigned it to button. 
    const style = value === "X" ? " box x" : "box o"
    return(
       <button className={style} onClick={onClick}>{value}</button>
    )
    
}

export default Box;